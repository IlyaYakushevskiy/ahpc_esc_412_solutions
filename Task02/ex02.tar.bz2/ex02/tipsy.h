#include "boost/endian/arithmetic.hpp"
#include "boost/endian/conversion.hpp"

namespace tipsy {
    using namespace boost::endian;

    // Header of a Tipsy file
    struct header {
        double dTime;
        std::uint32_t nBodies;
        std::uint32_t nDim;
        std::uint32_t nSph;
        std::uint32_t nDark;
        std::uint32_t nStar;
        std::uint32_t nPad;
    };

    inline void swap(header &hdr) {
        using boost::endian::big_to_native_inplace;
        // Swap all of the fields in "hdr"
        big_to_native_inplace(hdr.nBodies);
        // ... and so on
    }

    // Dark matter particle
    struct dark {
        float mass;
        float pos[3];
        float vel[3];
        float eps;
        float phi;
    };

    inline void swap(dark &d) {
        using boost::endian::big_to_native_inplace;
        // Swap all of the fields in "d"
    }

}
